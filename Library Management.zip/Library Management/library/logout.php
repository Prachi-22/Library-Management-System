<?php
session_start();
session_destroy();
echo "<script>
                    alert('Logged out');
                    window.location.href='./index.php';
                    </script>";
// header("location:index.php");
?>