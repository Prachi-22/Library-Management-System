<?php
session_start();
//check if the user is logged in
if(isset($_SESSION['email']))
{
  $email=$_SESSION['email'];
}
else
{
  header("location:index.php");
}

include('./db/connection.php');

//fetch student profile data
$fetch_query="SELECT * FROM students WHERE email='$email'";
$result_fetch=mysqli_query($mysqli,$fetch_query);
$row=mysqli_fetch_array($result_fetch);

//fetch gr
$find_gr="SELECT gr FROM students WHERE email='$email'";
$result_gr=mysqli_query($mysqli,$find_gr);
$row2=mysqli_fetch_array($result_gr);
$gr=$row2['gr'];

//fetch issued books
$book_query="SELECT * FROM issued_details WHERE gr='$gr'";
$book_result=mysqli_query($mysqli,$book_query);
$count=mysqli_num_rows($book_result);

// include('./db/connection.php');
?>


<!DOCTYPE html>

<html lang="en">



<head>

    <meta http-equiv="content-type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="Landing PAGE Html5 Template">

    <meta name="keywords" content="landing,startup,flat">

    <meta name="author" content="Made By GN DESIGNS">



    <title>Library Management System</title>



    <!-- // PLUGINS (css files) // -->

    <link href="assets/js/plugins/bootsnav_files/skins/color.css" rel="stylesheet">

    <link href="assets/js/plugins/bootsnav_files/css/animate.css" rel="stylesheet">

    <link href="assets/js/plugins/bootsnav_files/css/bootsnav.css" rel="stylesheet">

    <link href="assets/js/plugins/bootsnav_files/css/overwrite.css" rel="stylesheet">

    <link href="assets/js/plugins/owl-carousel/owl.carousel.css" rel="stylesheet">

    <link href="assets/js/plugins/owl-carousel/owl.theme.css" rel="stylesheet">

    <link href="assets/js/plugins/owl-carousel/owl.transitions.css" rel="stylesheet">

    <link href="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/magnific-popup.css" rel="stylesheet">

    <!--// ICONS //-->

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet">

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!--// BOOTSTRAP & Main //-->

    <link href="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="assets/css/main.css" rel="stylesheet">

</head>



<body>



    

    <!--//** Navigation**//-->

    <nav class="navbar navbar-default navbar-fixed white no-background bootsnav navbar-scrollspy" data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">



        <div class="container">

            <!-- Collect the nav links, forms, and other content for toggling -->

            <div class="collapse navbar-collapse" id="navbar-menu">

                <ul class="nav navbar-nav navbar-right">

                    <li class=""><a href="view_books_student.php">View Books</a></li>

                    <li class=""><a href="issue_book.php">Issue Book</a></li>

                    <li class=""><a href="return_book.php">Return Book</a></li>

                    <li class=""><a href="logout.php">Logout</a></li>

                </ul>

            </div>

        </div>

    </nav>



    <!--//** Banner**//-->

    <section id="home">

        <div class="container">

            <div class="row">

                <!-- Introduction -->

                <div class="col-md-6 caption">

                    <h1>Library Management System</h1>

                </div>

                <!-- Sign Up -->

                <div class="col-md-5 col-md-offset-1">

                    

                </div>

            </div>

        </div>

    </section>
    <br/><br/>
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="card">

                    <div class="card-body">
                        <div class="card-title mb-4">
                            <div class="d-flex justify-content-start">
                                <div class="image-container">
                                    <img src="./assets/img/user.jpg" id="imgProfile" style="width: 150px; height: 150px" class="img-thumbnail" />
                                </div>
                            </div>
                        </div>

                        <div class="row" style="margin:10px;">
                            <div class="col-12">
                                <ul class="nav nav-tabs mb-4" id="myTab" role="tablist">
                                    <li class="nav-item active">
                                        <a class="nav-link" id="basicInfo-tab" data-toggle="tab" href="#basicInfo" role="tab" aria-controls="basicInfo" aria-selected="true">Basic Info</a>
                                    </li>
                                    <!-- <li class="nav-item">
                                        <a class="nav-link" id="connectedServices-tab" data-toggle="tab" href="#connectedServices" role="tab" aria-controls="connectedServices" aria-selected="false">Connected Services</a>
                                    </li> -->
                                </ul>
                                <div class="tab-content ml-1" id="myTabContent">
                                    <div class="tab-pane fade show in active" id="basicInfo" role="tabpanel" aria-labelledby="basicInfo-tab">
                                        

                                        <div class="row">
                                            <div class="col-sm-3 col-md-2 col-5">
                                                <label style="font-weight:bold;">Full Name</label>
                                            </div>
                                            <div class="col-md-8 col-6">
                                                <?php
                                                echo $row['name'];
                                                ?>
                                            </div>
                                        </div>
                                        <hr />

                                        <div class="row">
                                            <div class="col-sm-3 col-md-2 col-5">
                                                <label style="font-weight:bold;">Gr No</label>
                                            </div>
                                            <div class="col-md-8 col-6">
                                                <?php
                                                    echo $row['gr'];
                                                ?>
                                            </div>
                                        </div>
                                        <hr />
                                        <div class="row">
                                            <div class="col-sm-3 col-md-2 col-5">
                                                <label style="font-weight:bold;">Email</label>
                                            </div>
                                            <div class="col-md-8 col-6">
                                                <?php
                                                    echo $row['email'];
                                                ?>
                                            </div>
                                        </div>
                                        <hr />
                                        
                                        <div class="row">
                                            <div class="col-sm-3 col-md-2 col-5">
                                                <label style="font-weight:bold;">Branch</label>
                                            </div>
                                            <div class="col-md-8 col-6">
                                                <?php
                                                    echo $row['branch'];
                                                ?>
                                            </div>
                                        </div>
                                        <hr />
                                        <div class="row">
                                            <div class="col-sm-3 col-md-2 col-5">
                                                <label style="font-weight:bold;">Year</label>
                                            </div>
                                            <div class="col-md-8 col-6">
                                                <?php
                                                    echo $row['year'];
                                                ?>
                                            </div>
                                        </div>
                                        <hr />
                                        <div class="row">
                                            <div class="col-sm-3 col-md-2 col-5">
                                                <label style="font-weight:bold;">Division</label>
                                            </div>
                                            <div class="col-md-8 col-6">
                                                <?php
                                                    echo $row['division'];
                                                ?>
                                            </div>
                                        </div>

                                        <hr />
                                        <div style="margin:30px 0 20px 0;">
                                            <h4>Issued Books</h4>
                                        </div>  
                                        <div style="margin-bottom:60px;">      
                                        <?php
                                            if($count == 0)
                                            {
                                                echo "No Books Issued...";
                                            }
                                            else
                                            {

                                                echo '<div class="row" style="border:1px solid black;color:red;font-size:60px;">';
                                                    echo '<div class="col-sm-1">';
                                                    echo '<h5>ID</h5>';   
                                                    echo  '</div>';

                                                        echo '<div class="col-sm-5">';
                                                            echo '<h5>Name</h5>';
                                                        echo '</div>';

                                                        echo '<div class="col-sm-3">';
                                                            echo '<h5>Author</h5>';
                                                        echo '</div>';

                                                        echo '<div class="col-sm-2">';
                                                            echo '<h5>Issued Date</h5>';
                                                        echo '</div>';

                                                    echo '</div>';

                                                while($record=mysqli_fetch_array($book_result))
                                                {
                                                    $id=$record['id'];
                                                    $query="SELECT * FROM books WHERE id='$id'";
                                                    $result=mysqli_query($mysqli,$query);
                                                    $book=mysqli_fetch_array($result);

                                                    echo "<div class='row' style='border:1px solid black'>";
                                                    echo "<div class='col-sm-1'>";
                                                    echo "<p>".$book['id']."</p>";
                                                    echo "</div>";

                                                    echo "<div class='col-sm-5'>";
                                                    echo "<p>".$book['name']."</p>";
                                                    echo "</div>";

                                                    echo "<div class='col-sm-3'>";
                                                    echo "<p>".$book['author']."</p>";
                                                    echo "</div>";

                                                    echo "<div class='col-sm-2'>";
                                                    echo "<p>".$record['issued_date']."</p>";
                                                    echo "</div>";

                                                    echo "</div>";                             

                                                }
                                            }
                                        ?>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>


                    </div>

                </div>
            </div>
        </div>
    </div>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->

    <script src="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>

    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>

    <script src="assets/js/plugins/bootsnav_files/js/bootsnav.js"></script>

    <script src="assets/js/plugins/typed.js-master/typed.js-master/dist/typed.min.js"></script>

    <script src="https://maps.googleapis.com/maps/api/js"></script>

    <script src="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>

    <script src="assets/js/main.js"></script>

</body>



</html>