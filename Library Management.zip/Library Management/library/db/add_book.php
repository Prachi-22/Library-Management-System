<?php
    include('connection.php');
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if(isset($_POST['add_book']))
        {
            $id=$_POST['id'];
            $name=$_POST['name'];
            $author=$_POST['author'];
            $quantity=$_POST['quantity'];

            echo $id;
            echo $name;
            echo $author;
            echo $quantity;
        
        //Insert into book table
        $query_book="INSERT INTO books values('$id','$name','$author','$quantity',$quantity)";
        $phone_result=mysqli_query($mysqli,$query_book);
        echo "<script>
                    alert('Book Added');
                    window.location.href='../add_book.php';
                    </script>";

        // header("location: ../add_book.php");
        }
        
    }
?>