<?php
    session_start();
    include('connection.php');
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if(isset($_POST['login']))
        {
            
            $email=$_POST['email'];
            $password=$_POST['password'];
            $user=$_POST['user'];
            //if no user is selected
            if($user=="Select User")
            {
                echo "<script>
                    alert('Select valid user');
                    window.location.href='../index.php';
                    </script>";
            }
            //if user is admin
            if($user=="admin")
            {
                $fetch_query="SELECT * FROM admin WHERE email='$email' AND password='$password'";
                $fetch_result=mysqli_query($mysqli,$fetch_query);
                $count=mysqli_num_rows($fetch_result);
                if($count) //insert only if admin exist
                {
                    $_SESSION['email']=$email;
                    // echo "go to admin dash";
                    header("location: ../admin_dash.php");
                }
                else{
                    echo "<script>
                    alert('Invalid Credentials');
                    window.location.href='../index.php';
                    </script>";
                }
            }
            //if user is student
            if($user=="student")
            {
                $fetch_query="SELECT * FROM students WHERE email='$email' AND password='$password'";
                $fetch_result=mysqli_query($mysqli,$fetch_query);
                $count=mysqli_num_rows($fetch_result);
                if($count) //insert only if student exist
                {
                    $_SESSION['email']=$email;
                    // echo "go to student dash";
                    header("location: ../student_dash.php");

                }    
                else{
                    echo "<script>
                    alert('Invalid Credentials');
                    window.location.href='../index.php';
                    </script>";
                }
            }

        // header("location: ../course_registration.php");
        }
        
    }
?>