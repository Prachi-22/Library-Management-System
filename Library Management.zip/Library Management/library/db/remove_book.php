<?php
    include('connection.php');
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if(isset($_POST['remove_book']))
        {
            $id=$_POST['id'];
            
            echo $id;
        //check if book is present
        $check_book="SELECT * FROM books WHERE ID='$id'";
        $result_book=mysqli_query($mysqli,$check_book);
        $count=mysqli_num_rows($result_book);
        if($count)
        {
            //Delete from books
        $query_book="DELETE FROM books WHERE id='$id'";
        $phone_result=mysqli_query($mysqli,$query_book);
        echo "<script>
                    alert('Book Removed');
                    window.location.href='../remove_book.php';
                    </script>";
        }
        else{
            echo "<script>
                    alert('Book doesnt exist');
                    window.location.href='../remove_book.php';
                    </script>";
        }
        
        // header("location: ../remove_book.php");
        }
        
    }
?>