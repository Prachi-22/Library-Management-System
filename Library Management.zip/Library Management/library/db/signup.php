<?php
    include('connection.php');
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if(isset($_POST['add_student']))
        {
            $name=$_POST['name'];
            $gr=$_POST['gr'];
            $branch=$_POST['branch'];
            $year=$_POST['year'];
            $division=$_POST['division'];
            $email=$_POST['email'];
            $password=$_POST['password'];

            echo $name;
            echo $gr;
            echo $branch;
            echo $year;
            echo $division;
            echo $email;
            echo $password;

        //Insert student record
        $query_student="INSERT INTO students VALUES('$name','$gr','$branch','$year','$division','$email','$password',0)";
        $pin_result=mysqli_query($mysqli,$query_student);
        echo "<script>
                    alert('Registration Successful');
                    window.location.href='../index.php';
                    </script>";
        
        // header("location: ../index.php");
        }
        
    }
?>