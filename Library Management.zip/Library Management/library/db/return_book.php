<?php
    session_start();
    $email=$_SESSION['email'];
    include('connection.php');
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if(isset($_POST['return_book']))
        {
            $id=$_POST['id'];

            //select the student
            $select_quantity="SELECT books_issued FROM students WHERE email='$email'";
            $select_result=mysqli_query($mysqli,$select_quantity);
            $row=mysqli_fetch_array($select_result);
            $issued_count=$row[0];

            //get available quantity
                $select_query="SELECT available_quantity FROM books WHERE id='$id'";
                $select_result=mysqli_query($mysqli,$select_query);
                $row=mysqli_fetch_array($select_result);
                $available=$row[0];

                $issued_count=$issued_count - 1;
                $available=$available + 1;

                //update issued count
                $update_query="UPDATE students SET books_issued='$issued_count' WHERE email='$email'";
                $update_result=mysqli_query($mysqli,$update_query);

                    //update available count
                    $update_query="UPDATE books SET available_quantity='$available' WHERE id='$id'";
                    $update_result=mysqli_query($mysqli,$update_query);

                    
                    //fetch gr
                    $fetch_gr="SELECT gr FROM students WHERE email='$email'";
                    $result_gr=mysqli_query($mysqli,$fetch_gr);
                    $row=mysqli_fetch_array($result_gr);
                    $gr=$row[0];
                    
                    $main_query="DELETE FROM issued_details WHERE gr='$gr' AND id='$id'";
                    $main_result=mysqli_query($mysqli,$main_query);

                    echo "<script>
                alert('Book returned');
                window.location.href='../return_book.php';
                </script>";

                }
                
                
    }
?>