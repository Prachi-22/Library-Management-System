<?php
    session_start();
    $email=$_SESSION['email'];
    include('connection.php');
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if(isset($_POST['issue_book']))
        {
            $id=$_POST['id'];

            //check if the book exist
            $check_book="SELECT * FROM books WHERE id='$id'";
            $result_book=mysqli_query($mysqli,$check_book);
            $book_count=mysqli_num_rows($result_book);
            if($book_count)
            {

                //select the student
            $select_query="SELECT books_issued FROM students WHERE email='$email'";
            $select_result=mysqli_query($mysqli,$select_query);
            $row=mysqli_fetch_array($select_result);
            $issued_count=$row[0];

            if($issued_count < 2)
            {
                $select_query="SELECT available_quantity FROM books WHERE id='$id'";
                $select_result=mysqli_query($mysqli,$select_query);
                $row=mysqli_fetch_array($select_result);
                $available=$row[0];
                // echo $available;

                if($available != 0)
                {
                    //fetch gr
                    $fetch_gr="SELECT gr FROM students WHERE email='$email'";
                    $result_gr=mysqli_query($mysqli,$fetch_gr);
                    $row_gr=mysqli_fetch_array($result_gr);
                    $gr=$row_gr[0];
                    // echo $gr;

                    //check if this book is already issued
                    $query_check="SELECT * FROM issued_details WHERE gr='$gr' AND id='$id'";
                    $check_result=mysqli_query($mysqli,$query_check);
                    $count=mysqli_num_rows($check_result);
                    if($count)
                    {
                        echo "<script>
                    alert('This book is already issued');
                    window.location.href='../issue_book.php';
                    </script>";
                    }                    
                    else
                    {
                        $issued_count=$issued_count + 1;
                        $available=$available - 1;

                        // echo $issued_count;
                        // echo $available;

                        //update issued count
                        $update_query="UPDATE students SET books_issued='$issued_count' WHERE email='$email'";
                        $update_result=mysqli_query($mysqli,$update_query);

                        //update available count
                        $update_query="UPDATE books SET available_quantity='$available' WHERE id='$id'";
                        $update_result=mysqli_query($mysqli,$update_query);

                        //update main table
                        $date_query="SELECT CURDATE()";
                        $result_date=mysqli_query($mysqli,$date_query);
                        $row=mysqli_fetch_array($result_date);
                        $date=$row[0];
                        // echo $date;

                        
                        
                        $main_query="INSERT INTO issued_details values('$gr','$id','$date')";
                        $main_result=mysqli_query($mysqli,$main_query);

                        echo "<script>
                    alert('Book Issued');
                    window.location.href='../issue_book.php';
                    </script>";
                    }

                }
                else{
                    echo "<script>
                    alert('Out of stock');
                    window.location.href='../issue_book.php';
                    </script>";
                }
            }
            else{
                echo "<script>
                    alert('Reached the limit');
                    window.location.href='../issue_book.php';
                    </script>";
                // echo "reached the limit";
            }

            }
            else{
                echo "<script>
                    alert('Book does not exist');
                    window.location.href='../issue_book.php';
                    </script>";
            }

            
        
        }
        echo "<script>
        window.location.href='../issue_book.php';
        </script>";
        // header("location: ../issue_book.php");
    }
?>