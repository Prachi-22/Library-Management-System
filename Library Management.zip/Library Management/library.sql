-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2018 at 10:56 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`email`, `password`) VALUES
('admin@123', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(30) NOT NULL,
  `name` varchar(40) NOT NULL,
  `author` varchar(40) NOT NULL,
  `total_quantity` int(10) NOT NULL,
  `available_quantity` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `name`, `author`, `total_quantity`, `available_quantity`) VALUES
(1, 'software engineering', 'pressman', 20, 11),
(2, 'Data structures through C in depth', 'S. k. Shrivastav ', 40, 38),
(17, 'Data Science Using R', 'Kevin McCall', 36, 35);

-- --------------------------------------------------------

--
-- Table structure for table `issued_details`
--

CREATE TABLE `issued_details` (
  `gr` int(10) NOT NULL,
  `id` int(20) NOT NULL,
  `issued_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `issued_details`
--

INSERT INTO `issued_details` (`gr`, `id`, `issued_date`) VALUES
(172121, 2, '2018-11-29'),
(172121, 1, '2018-11-29'),
(161213, 2, '2018-11-29'),
(161213, 17, '2018-11-29');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `name` varchar(30) NOT NULL,
  `gr` int(10) NOT NULL,
  `branch` varchar(30) NOT NULL,
  `year` varchar(10) NOT NULL,
  `division` varchar(10) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `books_issued` int(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`name`, `gr`, `branch`, `year`, `division`, `email`, `password`, `books_issued`) VALUES
('Niket Doke', 161213, 'Information Technology', 'TY', 'H', 'niket.doke16@vit.edu', 'password', 2),
('Atul Jagtap', 161530, 'Information Technology', 'TY', 'H', 'atul.jagtap16@vit.edu', 'password', 0),
('Abhijeet Raut', 172121, 'Information Technology', 'TY', 'H', 'abhijeet.raut17@vit.edu', 'password', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `issued_details`
--
ALTER TABLE `issued_details`
  ADD KEY `gr` (`gr`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`gr`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `issued_details`
--
ALTER TABLE `issued_details`
  ADD CONSTRAINT `issued_details_ibfk_1` FOREIGN KEY (`gr`) REFERENCES `students` (`gr`),
  ADD CONSTRAINT `issued_details_ibfk_2` FOREIGN KEY (`id`) REFERENCES `books` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
