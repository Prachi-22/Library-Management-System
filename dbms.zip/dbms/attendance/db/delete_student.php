<?php
    include('connection.php');
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if(isset($_POST['delete_student']))
        {
            $gr=$_POST['gr'];

        //Delete phone record first
        $query_phone="DELETE FROM phone WHERE stud_id='$gr'";
        $phone_result=mysqli_query($mysqli,$query_phone);

        // Delete Student record
        $query_stud="DELETE FROM students WHERE stud_id='$gr'";
        $stud_result=mysqli_query($mysqli,$query_stud);
        
        header("location: ../delete_student.php");
        }
        
    }
?>