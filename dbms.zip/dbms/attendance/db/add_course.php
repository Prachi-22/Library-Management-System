<?php
    include('connection.php');
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if(isset($_POST['add_course']))
        {
            $course_codee=$_POST['course_code'];
            $namee=$_POST['name'];
            $typee=$_POST['type'];
            $credit=$_POST['credit'];
            $teacher_id=$_POST['teacher_id'];

            $course_code=strtolower($course_codee);
            $type=strtolower($typee);
            $name=strtolower($namee);

            if($teacher_id=="Associated teacher id")
            {
                header("location: ../add_course.php");
            }

        //Get record pf teacher first
        $query_teacher="SELECT * FROM teachers WHERE teacher_id='$teacher_id'";
        $teacher_result=mysqli_query($mysqli,$query_teacher);
        $count=mysqli_num_rows($teacher_result);
        if($count)
        {
            //Insert into course name table first
        $query_course="INSERT INTO course_name values('$name','$credit')";
        $phone_result=mysqli_query($mysqli,$query_course);

        // Insert into course table
        $query_course="INSERT INTO courses values('$course_code','$name','$type')";
        $stud_result=mysqli_query($mysqli,$query_course);

        //Insert association table
        $query_association="INSERT INTO association values('$course_code','$teacher_id')";
            $association_result=mysqli_query($mysqli,$query_association);
        }

        
        
        header("location: ../add_course.php");
        }
        
    }
?>