<?php
    include('connection.php');
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if(isset($_POST['update_student']))
        {
            $f_name=$_POST['f_name'];
            $m_name=$_POST['m_name'];
            $l_name=$_POST['l_name'];
            $gr=$_POST['gr'];
        $roll_no=$_POST['roll_no'];
        $batch=$_POST['batch'];
        $division=$_POST['division'];
        $pincode=$_POST['pincode'];
        $city=$_POST['city'];
        $state=$_POST['state'];
        $old_phone=$_POST['old_phone'];
        $new_phone=$_POST['new_phone'];

        $rawdob = htmlentities($_POST['dob']);
        $dob = date('Y-m-d', strtotime($rawdob));

        if($f_name!="")
        {
           $update_query="UPDATE students SET f_name='$f_name' WHERE stud_id='$gr'";
           $delete_result=mysqli_query($mysqli,$update_query); 
        }
        if($m_name!="")
        {
           $update_query="UPDATE students SET m_name='$m_name' WHERE stud_id='$gr'";
           $delete_result=mysqli_query($mysqli,$update_query); 
        }
        if($l_name!="")
        {
           $update_query="UPDATE students SET l_name='$l_name' WHERE stud_id='$gr'";
           $delete_result=mysqli_query($mysqli,$update_query); 
        }
        if($dob!="")
        {
           $update_query="UPDATE students SET dob='$dob' WHERE stud_id='$gr'";
           $delete_result=mysqli_query($mysqli,$update_query); 
        }
        if($pincode!="")
        {
            $update_query="SELECT pin_code FROM students WHERE stud_id='$gr'";
            $update_result=mysqli_query($mysqli,$update_query);
            $row= mysqli_fetch_row($update_result);
            $p=$row[0];
            echo $p;

            // $update_query2="UPDATE pin SET pin_code='$pincode' WHERE pin_code='$p'";
            // $update_result2=mysqli_query($mysqli,$update_query2);



            $update_query="UPDATE students SET pin_code='$pincode' WHERE stud_id='$gr'";
            $update_result=mysqli_query($mysqli,$update_query);
        }
        if($batch!="")
        {
           $update_query="UPDATE students SET batch='$batch' WHERE stud_id='$gr'";
           $delete_result=mysqli_query($mysqli,$update_query); 
        }
        if($roll_no!="")
        {
           $update_query="UPDATE students SET roll_no='$roll_no' WHERE stud_id='$gr'";
           $delete_result=mysqli_query($mysqli,$update_query); 
        }
        if($division!="")
        {
           $update_query="UPDATE students SET division='$division' WHERE stud_id='$gr'";
           $delete_result=mysqli_query($mysqli,$update_query); 
        }
        if($old_phone!="" && $new_phone!="")
        {
           $update_query="UPDATE phone SET phone_no='$new_phone' WHERE stud_id='$gr' AND phone_no='$old_phone'";
           $delete_result=mysqli_query($mysqli,$update_query); 
        }
        //Insert pincode record first
        // $query_pin="INSERT INTO pin VALUES('$pincode','$city','$state')";
        // $pin_result=mysqli_query($mysqli,$query_pin);

        // Insert Student record
        // $qq="INSERT INTO tt VALUES('$f_name','$m_name','$l_name','$gr','$dob','$pincode','$batch','$roll_no','$division')";
        // $query_stud="INSERT INTO students VALUES('$gr','$dob','$f_name','$m_name','$l_name','$pincode','$batch','$roll_no','$division')";
        // $stud_result=mysqli_query($mysqli,$query_stud);
        
        //Insert Phone record
        // $query_phone="INSERT INTO phone VALUES('$gr','$phone')";
        // $phone_result=mysqli_query($mysqli,$query_phone);

        // header("location: ../update_student.php");
        }
        
    }
?>