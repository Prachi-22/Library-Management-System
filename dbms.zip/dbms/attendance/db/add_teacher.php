<?php
    include('connection.php');
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if(isset($_POST['add_teacher']))
        {
            $f_name=$_POST['f_name'];
            $m_name=$_POST['m_name'];
            $l_name=$_POST['l_name'];
            $teacher_id=$_POST['teacher_id'];
        $pincode=$_POST['pincode'];
        $city=$_POST['city'];
        $state=$_POST['state'];
        $experience=$_POST['experience'];

        $rawdob = htmlentities($_POST['dob']);
        $dob = date('Y-m-d', strtotime($rawdob));

        //Insert pincode record first
        $query_pin="INSERT INTO pin VALUES('$pincode','$city','$state')";
        $pin_result=mysqli_query($mysqli,$query_pin);

        // Insert Teacher record
        $query_teacher="INSERT INTO teachers VALUES('$teacher_id','$dob','$f_name','$m_name','$l_name','$pincode','$experience')";
        $stud_result=mysqli_query($mysqli,$query_teacher);
        
        header("location: ../add_teacher.php");
        }
        
    }
?>