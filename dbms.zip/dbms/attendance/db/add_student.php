<?php
    include('connection.php');
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if(isset($_POST['add_student']))
        {
            $f_name=$_POST['f_name'];
            $m_name=$_POST['m_name'];
            $l_name=$_POST['l_name'];
            $gr=$_POST['gr'];
        $roll_no=$_POST['roll_no'];
        $batch=$_POST['batch'];
        $division=$_POST['division'];
        $pincode=$_POST['pincode'];
        $city=$_POST['city'];
        $state=$_POST['state'];
        $phone=$_POST['phone'];

        $rawdob = htmlentities($_POST['dob']);
        $dob = date('Y-m-d', strtotime($rawdob));

        //Insert pincode record first
        $query_pin="INSERT INTO pin VALUES('$pincode','$city','$state')";
        $pin_result=mysqli_query($mysqli,$query_pin);

        // Insert Student record
        // $qq="INSERT INTO tt VALUES('$f_name','$m_name','$l_name','$gr','$dob','$pincode','$batch','$roll_no','$division')";
        $query_stud="INSERT INTO students VALUES('$gr','$dob','$f_name','$m_name','$l_name','$pincode','$batch','$roll_no','$division')";
        $stud_result=mysqli_query($mysqli,$query_stud);
        
        //Insert Phone record
        $query_phone="INSERT INTO phone VALUES('$gr','$phone')";
        $phone_result=mysqli_query($mysqli,$query_phone);

        header("location: ../index.php");
        }
        
    }
?>