<?php
    include('connection.php');
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if(isset($_POST['submit']))
        {
            $f_name=$_POST['f_name'];
            $roll_no=$_POST['roll_no'];
            $absent=$_POST['absent'];
            $name=$_POST['name'];
            $length=sizeof($absent);
            echo $length;
                
                //get course code
                $fetch_query="SELECT course_code FROM courses WHERE name='$name'";
                $fetch_result=mysqli_query($mysqli,$fetch_query);
                $row=mysqli_fetch_array($fetch_result);
                $course_code=$row['course_code'];
           // var_dump($roll_no);
            //$arr = array_merge(array_diff($roll_no, array(6)));
            //var_dump($arr);
            for($i = 0;$i < $length;$i++)
            {
                //get student id
                $fetch_query="SELECT stud_id FROM students WHERE roll_no='$absent[$i]'";
                $result_query=mysqli_query($mysqli,$fetch_query);
                $row=mysqli_fetch_array($result_query);
                $stud_id=$row[0];
                echo $stud_id;
                
                //get lecture details
                $fetch_query="SELECT lectures_conducted,lectures_attended FROM stud_attendance WHERE course_code='$course_code' AND stud_id='$stud_id'";
                $result_query=mysqli_query($mysqli,$fetch_query);
                $row=mysqli_fetch_array($result_query);
                $lectures_conducted=$row[0];
                $lectures_attended=$row[1];

                $lectures_conducted=$lectures_conducted+1;
                $attendance=($lectures_attended/$lectures_conducted)*100;
                
                $update_query="UPDATE stud_attendance SET lectures_attended='$lectures_attended',lectures_conducted='$lectures_conducted',attendance='$attendance' WHERE stud_id='$stud_id' AND course_code='$course_code'";
                $update_result=mysqli_query($mysqli,$update_query);

                $arr = array_merge(array_diff($roll_no, array($absent[$i])));
            }            

            $roll_length=sizeof($arr);
            echo $roll_length+1;
            for($i = 0;$i < $roll_length;$i++)
            {
                $fetch_query="SELECT stud_id FROM students WHERE roll_no='$arr[$i]'";
                $result_query=mysqli_query($mysqli,$fetch_query);
                $row=mysqli_fetch_array($result_query);
                $stud_id=$row[0];
                echo $stud_id;
                
                //get lecture details
                $fetch_query="SELECT lectures_conducted,lectures_attended FROM stud_attendance WHERE course_code='$course_code' AND stud_id='$stud_id'";
                $result_query=mysqli_query($mysqli,$fetch_query);
                $row=mysqli_fetch_array($result_query);
                $lectures_conducted=$row[0];
                $lectures_attended=$row[1];

                $lectures_attended=$lectures_attended+1;
                $lectures_conducted=$lectures_conducted+1;
                $attendance=($lectures_attended/$lectures_conducted)*100;
                
                $update_query="UPDATE stud_attendance SET lectures_attended='$lectures_attended',lectures_conducted='$lectures_conducted',attendance='$attendance' WHERE stud_id='$stud_id' AND course_code='$course_code'";
                $update_result=mysqli_query($mysqli,$update_query);
            }


        //Delete phone record first
        // $query_phone="DELETE FROM phone WHERE stud_id='$gr'";
        // $phone_result=mysqli_query($mysqli,$query_phone);

        // Delete Student record
        // $query_stud="DELETE FROM students WHERE stud_id='$gr'";
        // $stud_result=mysqli_query($mysqli,$query_stud);
        
        header("location: ../take_attendance.php");
        }
        
    }
?>