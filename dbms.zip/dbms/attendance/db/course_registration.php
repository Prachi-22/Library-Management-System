<?php
    include('connection.php');
    if($_SERVER["REQUEST_METHOD"] == "POST")
    {
        if(isset($_POST['register']))
        {
            
            $gr=$_POST['gr'];
            $course_code=$_POST['course_code'];
            if($course_code=="Select course code")
            {
                header("location: ../course_registration.php");
            }

            $fetch_query="SELECT * FROM students WHERE stud_id='$gr'";
            $fetch_result=mysqli_query($mysqli,$fetch_query);
            $count=mysqli_num_rows($fetch_result);
            if($count) //insert only if student exist
            {
                $fetch_query="SELECT name FROM courses WHERE course_code='$course_code'";
                $fetch_result=mysqli_query($mysqli,$fetch_query);
                $row=mysqli_fetch_array($fetch_result);
                //Insert into student_courses
                $query_assoc="INSERT INTO student_courses values('$gr','$course_code','$row[0]')";
                $phone_result=mysqli_query($mysqli,$query_assoc);

                //Insert into attendance table
                $query_attendance="INSERT INTO stud_attendance(stud_id,course_code,name) values('$gr','$course_code','$row[0]')";
                $query_result=mysqli_query($mysqli,$query_attendance);
            }
            

                

        header("location: ../course_registration.php");
        }
        
    }
?>