<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    
    // Create connection
    $mysqli = new mysqli($servername, $username, $password,'attendance');
    
    // Check connection
    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    } 

    if(isset($_POST['select_course']))
    {
        $name=$_POST['course_code'];
        if($name=="Select Course"){
            header("location: ./take_attendance.php");
        }

        //getting students registered for that course
        $fetch_query="SELECT DISTINCT stud_id FROM student_courses WHERE name='$name'";
        $result_fetch=mysqli_query($mysqli,$fetch_query);
        $count=mysqli_num_rows($result_fetch);
        if($count==0){
            echo "<script type='text/javascript'>";
            echo "alert('no students registerd');";
            echo "</script>";
        }

    }
?>

<!DOCTYPE html>

<html lang="en">



<head>

    <meta http-equiv="content-type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="Landing PAGE Html5 Template">

    <meta name="keywords" content="landing,startup,flat">

    <meta name="author" content="Made By GN DESIGNS">



    <title>Attendance Management System</title>



    <!-- // PLUGINS (css files) // -->

    <link href="assets/js/plugins/bootsnav_files/skins/color.css" rel="stylesheet">

    <link href="assets/js/plugins/bootsnav_files/css/animate.css" rel="stylesheet">

    <link href="assets/js/plugins/bootsnav_files/css/bootsnav.css" rel="stylesheet">

    <link href="assets/js/plugins/bootsnav_files/css/overwrite.css" rel="stylesheet">

    <link href="assets/js/plugins/owl-carousel/owl.carousel.css" rel="stylesheet">

    <link href="assets/js/plugins/owl-carousel/owl.theme.css" rel="stylesheet">

    <link href="assets/js/plugins/owl-carousel/owl.transitions.css" rel="stylesheet">

    <link href="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/magnific-popup.css" rel="stylesheet">

    <!--// ICONS //-->

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet">

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!--// BOOTSTRAP & Main //-->

    <link href="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="assets/css/main.css" rel="stylesheet">

    <style>
        input[type="checkbox"]{
  width: 20px; /*Desired width*/
  height: 20px; /*Desired height*/
}
        input[type="text"]{
            border: none;
    background: transparent;
        }
</style>

</head>



<body>



    

    <!--//** Navigation**//-->

    <nav class="navbar navbar-default navbar-fixed white no-background bootsnav navbar-scrollspy" data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">



        <div class="container">

            <!-- Collect the nav links, forms, and other content for toggling -->

            <div class="collapse navbar-collapse" id="navbar-menu">

                <ul class="nav navbar-nav navbar-right">

                    <li class=""><a href="index.php">Home</a></li>

                    <li class=""><a href="take_attendance.php">Take Attendance</a></li>

                    <li class=""><a href="view_attendance.php">View Attendance</a></li>

                    <li class=""><a href="course_registration.php">Course Registration</a></li>

                    <li class=""><a href="add_teacher.php">Add Teacher</a></li>

                    <li class=""><a href="add_course.php">Add Course</a></li>

                    <li class=""><a href="update_student.php">Update Student</a></li>

                    <li class=""><a href="delete_student.php">Delete Student</a></li>

                </ul>

            </div>

            <!-- /.navbar-collapse -->

        </div>

    </nav>



    <!--//** Banner**//-->

    <section id="home">

        <div class="container">

            <div class="row">

                <!-- Introduction -->

                <div class="col-md-6 caption">

                    <h1>Attendance Management System</h1>

                </div>
                
            </div>

        </div>

    </section>

    <div class="container">
        <div class="text-center heading">
            <h2>Attendance</h2>
        </div>
    <form action="db/submit_attendance.php" method="POST">
        <div class="row" style='border:1px solid black'>
            <div class="col-sm-3">
                <h5>Name of Student</h5>
            </div>

            <div class="col-sm-3">
                <h5>Roll No</h5>
            </div>

            <div class="col-sm-3">
                <h5>Absent</h5>
            </div>
        </div>

    <?php
    while($row=mysqli_fetch_array($result_fetch))
    {
        $stud_query="SELECT f_name,l_name,roll_no FROM students WHERE stud_id='$row[0]'";
        $stud_result=mysqli_query($mysqli,$stud_query);

        while($record=mysqli_fetch_array($stud_result))
        {
            echo "<div class='row' style='border:1px solid black'>";
            echo "<div class='col-sm-3'>";
            echo "<p><input type='text' name='f_name[]' value='".$record['f_name']." ".$record['l_name']."'/></p>";
            echo "</div>";

            echo "<div class='col-sm-3'>";
            echo "<p><input type='text' name='roll_no[]' value='".$record['roll_no']."'/></p>";
            echo "</div>";

            echo "<div class='col-sm-3'>";
            // echo "<input type='hidden' name='present[]'>";
            echo "<input type='checkbox' name='absent[]' value='".$record['roll_no']."'>";
            echo "</div>";
            echo "</div>";



        }
        
    }
    echo "<p><input type='hidden' name='name' value='".$name."'/></p>";

    ?>
        <div style="margin-top:30px;">
            <div class="form-group text-center">

                <button type="submit" class="btn btn-blue btn-block" name="submit">Add Attendance</button>

            </div>
        </div>

    </div>
            
    </form>
    <div>
<br/><br/><br/><br/><br/><br/><br/><br/><br/>
    </div>



    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->

    <script src="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>

    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>

    <script src="assets/js/plugins/bootsnav_files/js/bootsnav.js"></script>

    <script src="assets/js/plugins/typed.js-master/typed.js-master/dist/typed.min.js"></script>

    <script src="https://maps.googleapis.com/maps/api/js"></script>

    <script src="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>

    <script src="assets/js/main.js"></script>

</body>



</html>