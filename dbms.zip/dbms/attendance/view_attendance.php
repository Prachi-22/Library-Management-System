<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    
    // Create connection
    $mysqli = new mysqli($servername, $username, $password,'attendance');
    
    // Check connection
    if ($mysqli->connect_error) {
        die("Connection failed: " . $mysqli->connect_error);
    } 

    $fetch_query="SELECT name FROM courses";
    $result_fetch=mysqli_query($mysqli,$fetch_query);
?>

<!DOCTYPE html>

<html lang="en">



<head>

    <meta http-equiv="content-type" content="text/html; charset=UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description" content="Landing PAGE Html5 Template">

    <meta name="keywords" content="landing,startup,flat">

    <meta name="author" content="Made By GN DESIGNS">



    <title>Attendance Management System</title>



    <!-- // PLUGINS (css files) // -->

    <link href="assets/js/plugins/bootsnav_files/skins/color.css" rel="stylesheet">

    <link href="assets/js/plugins/bootsnav_files/css/animate.css" rel="stylesheet">

    <link href="assets/js/plugins/bootsnav_files/css/bootsnav.css" rel="stylesheet">

    <link href="assets/js/plugins/bootsnav_files/css/overwrite.css" rel="stylesheet">

    <link href="assets/js/plugins/owl-carousel/owl.carousel.css" rel="stylesheet">

    <link href="assets/js/plugins/owl-carousel/owl.theme.css" rel="stylesheet">

    <link href="assets/js/plugins/owl-carousel/owl.transitions.css" rel="stylesheet">

    <link href="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/magnific-popup.css" rel="stylesheet">

    <!--// ICONS //-->

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.6.3/css/font-awesome.css" rel="stylesheet">

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <!--// BOOTSTRAP & Main //-->

    <link href="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="assets/css/main.css" rel="stylesheet">

</head>



<body>



    

    <!--//** Navigation**//-->

    <nav class="navbar navbar-default navbar-fixed white no-background bootsnav navbar-scrollspy" data-minus-value-desktop="70" data-minus-value-mobile="55" data-speed="1000">



        <div class="container">

            <!-- Collect the nav links, forms, and other content for toggling -->

            <div class="collapse navbar-collapse" id="navbar-menu">

                <ul class="nav navbar-nav navbar-right">

                   <li class=""><a href="index.php">Home</a></li>

<li class=""><a href="take_attendance.php">Take Attendance</a></li>

<li class=""><a href="view_attendance.php">View Attendance</a></li>

<li class=""><a href="course_registration.php">Course Registration</a></li>

<li class=""><a href="add_teacher.php">Add Teacher</a></li>

<li class=""><a href="add_course.php">Add Course</a></li>

<li class=""><a href="update_student.php">Update Student</a></li>

<li class=""><a href="delete_student.php">Delete Student</a></li>

                </ul>

            </div>

        </div>

    </nav>



    <!--//** Banner**//-->

    <section id="home">

        <div class="container">

            <div class="row">

                <!-- Introduction -->

                <div class="col-md-6 caption">

                    <h1>Attendance Management System</h1>

                </div>

                <!-- Sign Up -->

                <div class="col-md-5 col-md-offset-1">

                    <form class="signup-form" method="POST" action="view_attendance.php">

                        <h2 class="text-center">View Attendance</h2>

                        <hr>

                        <div class="form-group">

                            <input type="number" name="gr" class="form-control" placeholder="Gr No" required="required">

                        </div>

                        <div class="form-group">
                            <?php
                                echo "<select name='course_code' class='form-control' style='padding:0;' placeholder='associated teacher id' required='required'>";
                                echo "<option>Select Course</option>";
                                while($row= mysqli_fetch_array($result_fetch)){
                                    echo "<option value='".$row['name'] ."'>".$row['name']."</option>";
                                }
                                echo "</select>";
                            ?>
                            
                        </div>

                        <div class="form-group text-center">

                            <button type="submit" class="btn btn-blue btn-block" name="show_percentage">Click here to get percentage</button>

                        </div>
                        
                        <div class="form-group">
                        <?php
                            if($_SERVER['REQUEST_METHOD'] == "POST")
                            {
                                    if(isset($_POST['show_percentage']))
                                    {
                                        $stud_id=$_POST['gr'];
                                        $name=$_POST['course_code'];
                                        if($name=="Select Course")
                                        {
                                            echo "<script type='text/javascript'>";
                                            echo "alert('please select course');";
                                            echo "</script>";
                                        }
                                        $get_query="SELECT attendance FROM stud_attendance WHERE stud_id='$stud_id' AND name='$name'";
                                        $result=mysqli_query($mysqli,$get_query);
                                        $row=mysqli_fetch_array($result);
                                        $percentage=$row[0];

                                        echo "<input type='text' readonly value='".$percentage."%"."' name='percentage' class='form-control' placeholder='Your percentages will be displayed here'>";

                        
                                        
                                    }
                            }
                        ?>

                        </div>
                    </form>

                </div>

            </div>

        </div>

    </section>


    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

    <!-- Include all compiled plugins (below), or include individual files as needed -->

    <script src="assets/bootstrap-3.3.7/bootstrap-3.3.7-dist/js/bootstrap.min.js"></script>

    <script src="assets/js/plugins/owl-carousel/owl.carousel.min.js"></script>

    <script src="assets/js/plugins/bootsnav_files/js/bootsnav.js"></script>

    <script src="assets/js/plugins/typed.js-master/typed.js-master/dist/typed.min.js"></script>

    <script src="https://maps.googleapis.com/maps/api/js"></script>

    <script src="assets/js/plugins/Magnific-Popup-master/Magnific-Popup-master/dist/jquery.magnific-popup.js"></script>

    <script src="assets/js/main.js"></script>

</body>



</html>